var img = document.getElementById('myImg');
var modal = document.getElementsByClassName("modal")[0];
var modalImg = document.getElementsByClassName("modal-content")[0];
var captionText = document.getElementsByClassName("caption")[0];
var span = document.getElementsByClassName("close")[0];

img.onclick = function(){
    modal.style.display = "block";
    modalImg.src = this.src;
    modalImg.alt = this.alt;
}

span.onclick = function() {
    modal.style.display = "none";
}



var img1 = document.getElementById('myImgP22');
var modal1 = document.getElementsByClassName("modal")[1];
var modalImg1 = document.getElementsByClassName("modal-content")[1];
var captionText1 = document.getElementsByClassName("caption")[1];
var span1 = document.getElementsByClassName("close")[1];

img1.onclick = function(){
    modal1.style.display = "block";
    modalImg1.src = this.src;
    modalImg1.alt = this.alt;
}

span1.onclick = function() {
    modal1.style.display = "none";
}



var img2 = document.getElementById('myImgP2');
var modal2 = document.getElementsByClassName("modal")[2];
var modalImg2 = document.getElementsByClassName("modal-content")[2];
var captionText2 = document.getElementsByClassName("caption")[2];
var span2 = document.getElementsByClassName("close")[2];

img2.onclick = function(){
    modal2.style.display = "block";
    modalImg2.src = this.src;
    modalImg2.alt = this.alt;
}

span2.onclick = function() {
    modal2.style.display = "none";
}

var img3 = document.getElementById('myImgP6');
var modal3 = document.getElementsByClassName("modal")[3];
var modalImg3 = document.getElementsByClassName("modal-content")[3];
var captionText3 = document.getElementsByClassName("caption")[3];
var span3 = document.getElementsByClassName("close")[3];

img3.onclick = function(){
    modal3.style.display = "block";
    modalImg3.src = this.src;
    modalImg3.alt = this.alt;
}

span3.onclick = function() {
    modal3.style.display = "none";
}

var img4 = document.getElementById('myImgP17');
var modal4 = document.getElementsByClassName("modal")[4];
var modalImg4 = document.getElementsByClassName("modal-content")[4];
var captionText4 = document.getElementsByClassName("caption")[4];
var span4 = document.getElementsByClassName("close")[4];

img4.onclick = function(){
    modal4.style.display = "block";
    modalImg4.src = this.src;
    modalImg4.alt = this.alt;
}

span4.onclick = function() {
    modal4.style.display = "none";
}

var img5 = document.getElementById('myImgP47');
var modal5 = document.getElementsByClassName("modal")[5];
var modalImg5 = document.getElementsByClassName("modal-content")[5];
var captionText5 = document.getElementsByClassName("caption")[5];
var span5 = document.getElementsByClassName("close")[5];

img5.onclick = function(){
    modal5.style.display = "block";
    modalImg5.src = this.src;
    modalImg5.alt = this.alt;
}

span5.onclick = function() {
    modal5.style.display = "none";
}

var img6 = document.getElementById('myImgP56');
var modal6 = document.getElementsByClassName("modal")[6];
var modalImg6 = document.getElementsByClassName("modal-content")[6];
var captionText6 = document.getElementsByClassName("caption")[6];
var span6 = document.getElementsByClassName("close")[6];

img6.onclick = function(){
    modal6.style.display = "block";
    modalImg6.src = this.src;
    modalImg6.alt = this.alt;
}

span6.onclick = function() {
    modal6.style.display = "none";
}

var img7 = document.getElementById('myImgP10');
var modal7 = document.getElementsByClassName("modal")[7];
var modalImg7 = document.getElementsByClassName("modal-content")[7];
var captionText7 = document.getElementsByClassName("caption")[7];
var span7 = document.getElementsByClassName("close")[7];

img7.onclick = function(){
    modal7.style.display = "block";
    modalImg7.src = this.src;
    modalImg7.alt = this.alt;
}

span7.onclick = function() {
    modal7.style.display = "none";
}

var img8 = document.getElementById('myImgP14');
var modal8 = document.getElementsByClassName("modal")[8];
var modalImg8 = document.getElementsByClassName("modal-content")[8];
var captionText8 = document.getElementsByClassName("caption")[8];
var span8 = document.getElementsByClassName("close")[8];

img8.onclick = function(){
    modal8.style.display = "block";
    modalImg8.src = this.src;
    modalImg8.alt = this.alt;
}

span8.onclick = function() {
    modal8.style.display = "none";
}

var img9 = document.getElementById('myImgP20');
var modal9 = document.getElementsByClassName("modal")[9];
var modalImg9 = document.getElementsByClassName("modal-content")[9];
var captionText9 = document.getElementsByClassName("caption")[9];
var span9 = document.getElementsByClassName("close")[9];

img9.onclick = function(){
    modal9.style.display = "block";
    modalImg9.src = this.src;
    modalImg9.alt = this.alt;
}

span9.onclick = function() {
    modal9.style.display = "none";
}

var img10 = document.getElementById('myImgP11');
var modal10 = document.getElementsByClassName("modal")[10];
var modalImg10 = document.getElementsByClassName("modal-content")[10];
var captionText10 = document.getElementsByClassName("caption")[10];
var span10 = document.getElementsByClassName("close")[10];

img10.onclick = function(){
    modal10.style.display = "block";
    modalImg10.src = this.src;
    modalImg10.alt = this.alt;
}

span10.onclick = function() {
    modal10.style.display = "none";
}

var img11 = document.getElementById('myImgP19');
var modal11 = document.getElementsByClassName("modal")[11];
var modalImg11 = document.getElementsByClassName("modal-content")[11];
var captionText11 = document.getElementsByClassName("caption")[11];
var span11 = document.getElementsByClassName("close")[11];

img11.onclick = function(){
    modal11.style.display = "block";
    modalImg11.src = this.src;
    modalImg11.alt = this.alt;
}

span11.onclick = function() {
    modal11.style.display = "none";
}

var img12 = document.getElementById('myImgP27');
var modal12 = document.getElementsByClassName("modal")[12];
var modalImg12 = document.getElementsByClassName("modal-content")[12];
var captionText12 = document.getElementsByClassName("caption")[12];
var span12 = document.getElementsByClassName("close")[12];

img12.onclick = function(){
    modal12.style.display = "block";
    modalImg12.src = this.src;
    modalImg12.alt = this.alt;
}

span12.onclick = function() {
    modal12.style.display = "none";
}